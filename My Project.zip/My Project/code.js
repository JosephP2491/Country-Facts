// Variables for various pieces of info like the name of the country, its population, capital, landarea, flag, and continent, filled by data from the data table
var countryName = getColumn("Country Info", "Country");
var population = getColumn("Country Info", "Population");
var capital = getColumn("Country Info", "Capital");
var landArea = getColumn("Country Info", "Land Area (km²)");
var flag = getColumn("Country Info", "Flag");
var continent = getColumn("Country Info", "Continent");
//declaring filtered variables
var populationFiltered;
var capitalFiltered;
var landareaFiltered;
var flagFiltered;
var continentFiltered;
// Hides image upon start
hideElement("flagImage");
//On event "CountryButton" is clicked, the text box will be reset, the previous country's flag will be hidden, and the getInfo function will be run
onEvent("CountryButton", "click", function( ) {
  hideElement("flagImage");
  getInfo(getText("countryInput"));
});
//getInfo- This function obtains all of the info regarding the inputted country including, capital, population, land area km^2, continent, and its flag. 
//countryChosen {string}- This parameter obtains the name of the country inputted by the user.  
//returns populationFiltered, capitalFiltered, landareaFiltered, flagFiltered, continentFiltered, and countryChosen  
//sets text to give all of the information of the country inputted
//shows the flag of the country inputted
function getInfo(countryChosen) {
  for (var i = 0; i < countryName.length; i++) {
    if (countryChosen == countryName[i]) {
       populationFiltered = population[i];
       capitalFiltered = capital[i];
       landareaFiltered = landArea[i];
       flagFiltered = flag[i];
       continentFiltered = continent[i];
       setImageURL("flagImage", flagFiltered);
       setText("countryText2", (((((((((((("The country you chose is " + countryChosen) + ".") + " Its capital is ") + capitalFiltered) + ", and has a population of ") + populationFiltered) + ".") + " ") + countryChosen + " is located on the continent of ") + continentFiltered) + ", and has an area of ") + landareaFiltered) + " km^2.");
       showElement("flagImage");
    }
  }
  return populationFiltered, capitalFiltered, landareaFiltered, flagFiltered, continentFiltered, countryChosen;
}
